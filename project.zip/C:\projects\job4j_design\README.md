# Job4j_design Junior project.
In this level, we will create a job scraper for a popular site.
Also in this course we will discover:
- Collections Pro
- I/O, Socket
- TDD
- Java memory model
- SQl, JDBC
package ru.job4j.serialization.json;

public class StarSystem {

    String name;
    int countOfPlanets;
    Planet[] habitablePlanets;
}

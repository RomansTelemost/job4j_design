package ru.job4j.serialization.json;

public class Planet {

    String name;
    long age;
    int landArea;
    long distanceFromStar;
    boolean habitable;
}
